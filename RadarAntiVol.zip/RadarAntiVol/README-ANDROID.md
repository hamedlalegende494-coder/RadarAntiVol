# Radar Anti-Vol — App Android native

Cette app tourne en arrière-plan sur ton téléphone, envoie sa position à Firestore, et exécute réellement les commandes **Localiser / Sonner / Verrouiller / Effacer** envoyées depuis `antivol-dashboard.html`.

## ⚠️ À lire avant de commencer

- **Verrouiller et effacer sont réels et irréversibles.** "Effacer" déclenche une réinitialisation d'usine complète du téléphone. N'installe cette app et n'active l'administrateur de l'appareil que sur **ton propre téléphone**.
- Android exige une **notification permanente et visible** tant que le service de localisation tourne — impossible de la cacher, c'est une protection du système contre les apps espionnes.
- Cette app peut être désinstallée par quiconque a accès au téléphone déverrouillé (désactiver l'administrateur de l'appareil dans les réglages, puis désinstaller). Elle ne survit pas à une réinitialisation d'usine faite en mode récupération. Pour cette résistance-là, seul le verrou constructeur (Localiser mon appareil / Localiser mon iPhone) fait le travail — garde-le activé en complément.
- Cette app n'est pas destinée à être publiée sur le Play Store telle quelle (les règles de Google sur les permissions "Administrateur de l'appareil" et la localisation en arrière-plan sont strictes) — elle est prévue pour un usage personnel, installée manuellement sur ton téléphone.

## 1. Ajouter une app Android à ton projet Firebase

1. Console Firebase → ton projet (`dashboard-9fa53`) → ⚙️ **Paramètres du projet** → *Vos applications* → icône Android.
2. **Nom du package Android** : `com.radar.antivol` (doit correspondre exactement à `applicationId` dans `app/build.gradle` — ne change pas l'un sans l'autre).
3. Pas besoin de renseigner le SHA-1 pour ce projet (utile seulement pour la connexion Google ou les liens dynamiques, qu'on n'utilise pas ici).
4. Télécharge le fichier **`google-services.json`** généré.
5. Place ce fichier à la racine du dossier `app/` du projet (`RadarAntiVol/app/google-services.json`) — au même niveau que `app/build.gradle`.

## 2. Ouvrir et compiler le projet

1. Installe [Android Studio](https://developer.android.com/studio) si tu ne l'as pas déjà.
2. **Open** → sélectionne le dossier `RadarAntiVol` (celui qui contient `settings.gradle`).
3. Laisse Gradle synchroniser (ça peut prendre plusieurs minutes la première fois — il télécharge les dépendances).
4. Branche ton téléphone en USB, active le **Mode développeur** puis le **Débogage USB** (Réglages → À propos du téléphone → appuie 7 fois sur "Numéro de build" → Réglages → Options pour les développeurs).
5. Clique sur ▶️ **Run** dans Android Studio — l'app s'installe et se lance directement sur ton téléphone.

## 3. Configurer l'app sur le téléphone

Dans l'app, dans l'ordre :
1. **Se connecter** ou **Créer un compte** — utilise n'importe quel compte (le même que celui d'`antivol-dashboard.html` si tu veux piloter ce téléphone depuis là).
2. **1. Autoriser la localisation** → accepte, puis quand Android redemande pour l'arrière-plan, choisis **"Autoriser tout le temps"** (pas seulement "Uniquement pendant l'utilisation de l'appli", sinon le suivi s'arrêtera dès que tu fermes l'app).
3. **2. Ignorer l'optimisation de batterie** → accepte, sinon Android risque de tuer le service au bout de quelques heures.
4. **3. Activer Administrateur de l'appareil** → accepte (nécessaire pour que Verrouiller/Effacer fonctionnent réellement).
5. **Démarrer la protection** → le service se lance, une notification permanente apparaît.

Sur certains téléphones (Xiaomi, Huawei, Oppo...), il faut en plus activer manuellement l'**autorisation de démarrage automatique** pour cette app dans les réglages du fabricant, sinon elle ne survit pas à un redémarrage malgré `BootReceiver`.

## 4. Piloter le téléphone

Ouvre `antivol-dashboard.html` (déployé sur GitHub Pages, comme les autres pages) depuis n'importe quel navigateur, connecte-toi avec le même compte, et utilise les boutons Localiser / Sonner / Verrouiller / Effacer.

## Modèle de données Firestore

`devices/{uid}` : `ownerId`, `name`, `online`, `lat`, `lng`, `battery`, `lastSeen`, `command` (`{type, issuedAt, acked}`).
