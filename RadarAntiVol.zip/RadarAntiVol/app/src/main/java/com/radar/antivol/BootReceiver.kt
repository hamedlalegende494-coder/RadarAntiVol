package com.radar.antivol

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.google.firebase.auth.FirebaseAuth

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            // Ne redémarre le suivi que si un compte est déjà connecté sur ce téléphone.
            if (FirebaseAuth.getInstance().currentUser != null) {
                val serviceIntent = Intent(context, LocationForegroundService::class.java)
                ContextCompat.startForegroundService(context, serviceIntent)
            }
        }
    }
}
