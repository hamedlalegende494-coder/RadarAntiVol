package com.radar.antivol

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    private lateinit var statusText: TextView
    private lateinit var emailInput: EditText
    private lateinit var passInput: EditText
    private lateinit var setupSection: android.widget.LinearLayout

    // Demande la localisation précise + approximative en une fois.
    private val locationPermissionRequest = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val granted = results.values.any { it }
        if (granted && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // La localisation en arrière-plan doit être demandée séparément, après coup.
            backgroundLocationRequest.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
        } else {
            toast(if (granted) "Localisation autorisée." else "Localisation refusée : la protection ne pourra pas fonctionner.")
        }
    }

    private val backgroundLocationRequest = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        toast(if (granted) "Localisation en arrière-plan autorisée." else "Sans l'autorisation \"Tout le temps\", le suivi s'arrêtera quand l'app n'est pas ouverte.")
    }

    private val deviceAdminRequest = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val adminComponent = ComponentName(this, MyDeviceAdminReceiver::class.java)
        toast(if (dpm.isAdminActive(adminComponent)) "Administrateur de l'appareil activé." else "Administrateur de l'appareil non activé : verrouillage/effacement à distance indisponibles.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        statusText = findViewById(R.id.statusText)
        emailInput = findViewById(R.id.emailInput)
        passInput = findViewById(R.id.passInput)
        setupSection = findViewById(R.id.setupSection)

        findViewById<Button>(R.id.loginButton).setOnClickListener { login() }
        findViewById<Button>(R.id.signupButton).setOnClickListener { signup() }
        findViewById<Button>(R.id.permLocationButton).setOnClickListener { requestLocationPermissions() }
        findViewById<Button>(R.id.permBatteryButton).setOnClickListener { requestIgnoreBatteryOptimization() }
        findViewById<Button>(R.id.permAdminButton).setOnClickListener { requestDeviceAdmin() }
        findViewById<Button>(R.id.startServiceButton).setOnClickListener { startProtection() }
        findViewById<Button>(R.id.logoutButton).setOnClickListener { logout() }

        refreshUiForAuthState()
    }

    private fun refreshUiForAuthState() {
        val user = auth.currentUser
        if (user != null) {
            statusText.text = "Connecté : ${user.email}"
            setupSection.visibility = android.view.View.VISIBLE
            // Crée le document Firestore de cet appareil s'il n'existe pas encore.
            db.collection("devices").document(user.uid).get().addOnSuccessListener { snap ->
                if (!snap.exists()) {
                    db.collection("devices").document(user.uid).set(
                        mapOf(
                            "ownerId" to user.uid,
                            "name" to (user.email ?: "Mon téléphone"),
                            "online" to false,
                            "lat" to null,
                            "lng" to null,
                            "battery" to null,
                            "lastSeen" to null,
                            "command" to null
                        )
                    )
                }
            }
        } else {
            statusText.text = "Non connecté"
            setupSection.visibility = android.view.View.GONE
        }
    }

    private fun login() {
        val email = emailInput.text.toString().trim()
        val pass = passInput.text.toString()
        auth.signInWithEmailAndPassword(email, pass)
            .addOnSuccessListener { refreshUiForAuthState() }
            .addOnFailureListener { toast("Connexion impossible : ${it.message}") }
    }

    private fun signup() {
        val email = emailInput.text.toString().trim()
        val pass = passInput.text.toString()
        if (email.isEmpty() || pass.length < 6) {
            toast("E-mail requis et mot de passe d'au moins 6 caractères.")
            return
        }
        auth.createUserWithEmailAndPassword(email, pass)
            .addOnSuccessListener { refreshUiForAuthState() }
            .addOnFailureListener { toast("Création impossible : ${it.message}") }
    }

    private fun logout() {
        stopService(Intent(this, LocationForegroundService::class.java))
        auth.signOut()
        refreshUiForAuthState()
    }

    private fun requestLocationPermissions() {
        locationPermissionRequest.launch(
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
        )
    }

    private fun requestIgnoreBatteryOptimization() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
            intent.data = android.net.Uri.parse("package:$packageName")
            startActivity(intent)
        } else {
            toast("Déjà exempté de l'optimisation de batterie.")
        }
    }

    private fun requestDeviceAdmin() {
        val adminComponent = ComponentName(this, MyDeviceAdminReceiver::class.java)
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
        intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
        intent.putExtra(
            DevicePolicyManager.EXTRA_ADD_EXPLANATION,
            "Nécessaire pour verrouiller ou effacer ce téléphone à distance s'il est perdu ou volé."
        )
        deviceAdminRequest.launch(intent)
    }

    private fun startProtection() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            toast("Autorise d'abord la localisation (étape 1).")
            return
        }
        val serviceIntent = Intent(this, LocationForegroundService::class.java)
        ContextCompat.startForegroundService(this, serviceIntent)
        toast("Protection démarrée.")
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
