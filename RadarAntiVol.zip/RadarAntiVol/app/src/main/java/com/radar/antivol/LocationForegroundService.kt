package com.radar.antivol

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

/**
 * Service qui tourne en arrière-plan avec une notification visible (obligatoire
 * sur Android). Il envoie la position dans Firestore toutes les ~20 secondes,
 * et écoute en continu le champ "command" du document de cet appareil pour
 * exécuter localiser / sonner / verrouiller / effacer dès qu'une commande arrive.
 */
class LocationForegroundService : Service() {

    private lateinit var fusedClient: FusedLocationProviderClient
    private lateinit var locationCallback: LocationCallback
    private var commandListener: ListenerRegistration? = null
    private var lastAckedAt: Long = 0
    private var lastSentAt: Long = 0
    private var ringPlayer: MediaPlayer? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        fusedClient = LocationServices.getFusedLocationProviderClient(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, buildNotification())
        startLocationUpdates()
        startCommandListener()
        // START_STICKY : demande à Android de relancer ce service s'il est tué.
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        fusedClient.removeLocationUpdates(locationCallback)
        commandListener?.remove()
        markOffline()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ---------------------------------------------------------------------
    // Notification obligatoire (Android n'autorise pas de service de
    // localisation en premier plan invisible, par transparence envers l'utilisateur).
    // ---------------------------------------------------------------------
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "radar_channel", "Protection anti-vol", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification() =
        NotificationCompat.Builder(this, "radar_channel")
            .setContentTitle("Radar Anti-Vol actif")
            .setContentText("Ce téléphone est protégé et localisable.")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true)
            .build()

    // ---------------------------------------------------------------------
    // Localisation
    // ---------------------------------------------------------------------
    private fun startLocationUpdates() {
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 15_000L).build()
        locationCallback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                val loc = result.lastLocation ?: return
                sendLocation(loc.latitude, loc.longitude)
            }
        }
        try {
            fusedClient.requestLocationUpdates(request, locationCallback, mainLooper)
        } catch (e: SecurityException) {
            // Permission retirée entre-temps : on ne plante pas le service pour autant.
        }
    }

    private fun sendLocation(lat: Double, lng: Double) {
        val now = System.currentTimeMillis()
        if (now - lastSentAt < 15_000) return
        lastSentAt = now

        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        val battery = readBatteryPercent()

        FirebaseFirestore.getInstance().collection("devices").document(uid)
            .update(
                mapOf(
                    "lat" to lat,
                    "lng" to lng,
                    "battery" to battery,
                    "online" to true,
                    "lastSeen" to com.google.firebase.firestore.FieldValue.serverTimestamp()
                )
            )
    }

    private fun markOffline() {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        FirebaseFirestore.getInstance().collection("devices").document(uid)
            .update("online", false)
    }

    private fun readBatteryPercent(): Int {
        val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }

    // ---------------------------------------------------------------------
    // Commandes envoyées depuis le tableau de bord web
    // ---------------------------------------------------------------------
    private fun startCommandListener() {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        commandListener = FirebaseFirestore.getInstance().collection("devices").document(uid)
            .addSnapshotListener { snap, _ ->
                val command = snap?.get("command") as? Map<*, *> ?: return@addSnapshotListener
                val acked = command["acked"] as? Boolean ?: true
                val issuedAt = (command["issuedAt"] as? Long) ?: (command["issuedAt"] as? Double)?.toLong() ?: 0L
                if (acked || issuedAt == lastAckedAt) return@addSnapshotListener
                lastAckedAt = issuedAt

                when (command["type"] as? String) {
                    "locate" -> fusedClient.lastLocation.addOnSuccessListener { loc ->
                        loc?.let { sendLocation(it.latitude, it.longitude) }
                    }
                    "ring" -> playRingtone()
                    "lock" -> lockDevice()
                    "erase" -> eraseDevice()
                }

                FirebaseFirestore.getInstance().collection("devices").document(uid)
                    .update("command.acked", true)
            }
    }

    private fun playRingtone() {
        stopRingtone()
        val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audioManager.setStreamVolume(
            AudioManager.STREAM_MUSIC,
            audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
            0
        )
        val uri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        ringPlayer = MediaPlayer().apply {
            setAudioStreamType(AudioManager.STREAM_MUSIC)
            setDataSource(this@LocationForegroundService, uri)
            isLooping = true
            prepare()
            start()
        }
        // Coupe automatiquement après 60 secondes.
        android.os.Handler(mainLooper).postDelayed({ stopRingtone() }, 60_000)
    }

    private fun stopRingtone() {
        ringPlayer?.stop()
        ringPlayer?.release()
        ringPlayer = null
    }

    /** Verrouille immédiatement l'écran — nécessite que l'administrateur de l'appareil soit actif. */
    private fun lockDevice() {
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val adminComponent = ComponentName(this, MyDeviceAdminReceiver::class.java)
        if (dpm.isAdminActive(adminComponent)) {
            dpm.lockNow()
        }
    }

    /**
     * Réinitialise le téléphone aux paramètres d'usine — IRRÉVERSIBLE.
     * Nécessite que l'administrateur de l'appareil soit actif.
     */
    private fun eraseDevice() {
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val adminComponent = ComponentName(this, MyDeviceAdminReceiver::class.java)
        if (dpm.isAdminActive(adminComponent)) {
            dpm.wipeData(0)
        }
    }
}
